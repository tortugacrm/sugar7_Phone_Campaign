<?php
// WARNING: The contents of this file are auto-generated.

//Merged from custom/Extension/modules/Opportunities/Ext/WirelessLayoutdefs/opportunities_calls_1_Opportunities.php

 // created: 2014-07-01 16:30:11
$layout_defs["Opportunities"]["subpanel_setup"]['opportunities_calls_1'] = array (
  'order' => 100,
  'module' => 'Calls',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_OPPORTUNITIES_CALLS_1_FROM_CALLS_TITLE',
  'get_subpanel_data' => 'opportunities_calls_1',
);
