<?php
// WARNING: The contents of this file are auto-generated.

//Merged from custom/Extension/modules/Opportunities/Ext/Vardefs/opportunities_calls_1_Opportunities.php

// created: 2014-07-01 16:30:11
$dictionary["Opportunity"]["fields"]["opportunities_calls_1"] = array (
  'name' => 'opportunities_calls_1',
  'type' => 'link',
  'relationship' => 'opportunities_calls_1',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_OPPORTUNITIES_CALLS_1_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'opportunities_calls_1opportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);
