<?php
// WARNING: The contents of this file are auto-generated.

//Merged from custom/Extension/modules/Calls/Ext/Language/en_us.customopportunities_calls_1.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_CALLS_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
