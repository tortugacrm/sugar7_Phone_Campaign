<?php
// WARNING: The contents of this file are auto-generated.

//Merged from custom/Extension/modules/Opportunities/Ext/Language/en_us.customopportunities_calls_1.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_OPPORTUNITIES_CALLS_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITIES_CALLS_1_FROM_CALLS_TITLE'] = 'Calls (campaign)';

//Merged from custom/Extension/modules/Opportunities/Ext/Language/en_us.PhoneCampaignLogs.php


$mod_strings['LBL_OPPORTUNITIES_CALLS_1_FROM_OPPORTUNITIES_TITLE'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITIES_CALLS_1_FROM_CALLS_TITLE'] = 'Calls (campaign)';
