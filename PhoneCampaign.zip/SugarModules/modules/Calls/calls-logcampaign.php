<?php

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class CallsLogCampaignHook
{
	
	public static function AddCampaignLog(Call $call, $event, $args)
	{
		$GLOBALS['log']->warn("######## Entering AddCampaignLog");
		// only new Calls will generate a new Campaign log
		if ($call->date_entered != $call->date_modified) {
			$GLOBALS['log']->warn(">>>>> Existing record. Exit");
			return; exit;
		}
		
		if ($call->parent_type != 'Contacts') {
			$GLOBALS['log']->warn(">>>>> Not related to a contact. Exit");
			return; 
		}

		if (!$call->load_relationship('opportunities_calls_1')) {
			$GLOBALS['log']->warn(">>>>> Not related to an Opportunity. Exit");
			return; 
		}
		$Opportunities = $call->opportunities_calls_1->getBeans();
		if (!empty($Opportunities))
		{
			//order the results
			reset($Opportunities);
			//first record in the list is the parent
			$opty = current($Opportunities);
			
			/*
			// uncomment this section if you want to get only 1 Campaign log per campaign / contact
			// which does not make sense because a customer might be called several times for the same campaign
			// test if Campaign_log already exists? (same campaign, same contact)
			$CL = new CampaignLog();
			$cl_list = $CL->get_full_list("", "campaign_log.campaign_id='".$opty->campaign_id."' and campaign_log.related_id='".$call->parent_id."'");
			if (count($cl_list)>0) {
				$GLOBALS['log']->warn(">>>>> Campaign log record already exists. Exit");
				return; 
			}
			*/
			$campaign_log = new CampaignLog();
			$campaign_log->campaign_id = $opty->campaign_id;
			//$campaign_log->target_tracker_key = '';
			$campaign_log->target_id = $call->parent_id;  // the contact id
			$campaign_log->target_type = 'Contacts'; 
			$campaign_log->activity_type = 'phone';
			$campaign_log->activity_date = TimeDate::getInstance()->nowDb();
			$campaign_log->related_id = $call->parent_id;
			$campaign_log->related_type = 'Contacts';
			//$campaign_log->list_id;
			$campaign_log->hits = 1;
			//$campaign_log->more_information;
			$campaign_log->marketing_id = $opty->campaign_id;		
			$campaign_log->save();
		}
		$GLOBALS['log']->warn("######## Exiting AddCampaignLog");
	}
		
}

?>
